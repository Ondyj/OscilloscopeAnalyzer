Aplikace_a_knihovny -Hlavni_aplikace obsahuje vysledny OscilloscopeAnalyzer.exe soubor a potrebne knihovny pro spusteni
		    -Zdrojove_soubory obsahuje vsechny zdrojove kody a konfiguracni soubory

Text_prace -Obsahuje pdf bakalarske prace, obrazky a zdrojove .tex soubory

Vstupni_data -Obsahuji vstupni data pro overeni funkcnosti programu